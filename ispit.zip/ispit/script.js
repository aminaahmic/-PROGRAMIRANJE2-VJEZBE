
let globalPodaci = [];
let k1_preuzmiDrzave = () => {
    //https://wrd-fit.info/ -> Ispit20240713 -> GetNovePonude

    let url = `https://wrd-fit.info/Ispit20240713/GetNovePonude`
    destinacije.innerHTML = '';//brisemo destinacije
    fetch(url)
        .then(r => {
            if (r.status !== 200) {
                //greska
                return;
            }
            r.json().then(t => {

                let b = 0;
                globalPodaci = t.podaci //setujemo globalnu varijablu

                for (const x of t.podaci) {
                    destinacije.innerHTML += `
                    <div class="destination-card">
                    <img class="destination-img" src="${x.imageUrl}"/>
                    <h2 class="destination-name">${x.drzava}</h2>
                    <div class="destination-date">${x.naredniPolazak.zaDana} | Slobodno mjesta: ${x.naredniPolazak.brojSlobodnihMjesta}</div>
                    <div class="destination-description">
                    ${x.opisPonude}
                    </div>
                    ${prikaziGradovePonude(x)}
                    <button class="destination-button" onclick="k2_odaberiDestinaciju(${b})">K2 Odaberi destinaciju</button>
                  </div>
                    `
                    b++;
                }
            })
        })
}
let dugmePretrage = document.getElementById("search-button");
let popuni = () => {
    let pretragaInput = document.getElementById("search-input").value;
    console.log(globalPodaci);
    destinacije.innerHTML = ``;
    for (let i = 0; i < 6; i++) {
        let drzavaInput = globalPodaci[i].drzava;
        if (drzavaInput == pretragaInput) {
            ispuni(globalPodaci[i], i);
        }
        for (let j = 0; j < 4; j++) {
            let gradInput = globalPodaci[i].boravakGradovi[j].nazivGrada;
            let hotelInput = globalPodaci[i].boravakGradovi[j].hotelNaziv;
            if (gradInput == pretragaInput || hotelInput == pretragaInput) {
                ispuni(globalPodaci[i], i);
            }
        }
    }
}
let ispuni = (x, b) => {
    destinacije.innerHTML += `
        <div class="destination-card">
        <img class="destination-img" src="${x.imageUrl}"/>
        <h2 class="destination-name">${x.drzava}</h2>
        <div class="destination-date">${x.naredniPolazak.zaDana} | Slobodno mjesta: ${x.naredniPolazak.brojSlobodnihMjesta}</div>
        <div class="destination-description">
        ${x.opisPonude}
        </div>
        ${prikaziGradovePonude(x)}
        <button class="destination-button" onclick="k2_odaberiDestinaciju(${b})">K2 Odaberi destinaciju</button>
      </div>
        `;
}
let prikaziGradovePonude = (x) => {
    let s = "<table>";

    for (const g of x.boravakGradovi) {
        s += `<tr>
        <td>${g.nazivGrada}</td>
        <td>${g.hotelNaziv}</td>
        <td>${g.brojNocenja} dana</td>
            
        </tr>`
    }
    s += "</table>"
    return s;
}

let k2_odaberiDestinaciju = (rbDrzave) => {

    let destinacijObj = globalPodaci[rbDrzave];
    drzavaText.value = destinacijObj.drzava;

    let s = "";
    let rbPolaska = 0;
    for (const o of destinacijObj.planiranaPutovanja) {
        s += `
        <tr>
            <td>ID ${o.putovanjeId}</td>
            <td>${o.datumPolaska}</td>
            <td>${o.datumPovratka}</td>
            <td>${o.slobodnaMjestaCount}</td>
            <td>${o.brojDana}</td>
            <td>${o.cijenaPoOsobi} €</td>
            <td><button onclick='K3_odaberiPutovanje(${rbDrzave}, ${rbPolaska}, ${o.putovanjeId})'>K3 Odaberi putovanje</button></td>
        </tr>`
        rbPolaska++;
    }
    putovanjaTabela.innerHTML = s;
}
let drzavaG;
let datum=document.getElementById("datumPolaska");
let cijena=document.getElementById("cijenaPoGostu");
let globalID;
let K3_odaberiPutovanje = (rbDrzave, rbPolaska, putovanjeid) => {
globalID=putovanjeid;
drzavaG=globalPodaci[rbDrzave].drzava;
datum = globalPodaci[rbDrzave].planiranaPutovanja[rbPolaska].datumPolaska;
cijena=globalPodaci[rbDrzave].planiranaPutovanja[rbPolaska].cijenaPoOsobi;
generisiPromjenuGradova(globalPodaci[rbDrzave].boravakGradovi);
datumPolaska.value=`${datum}`;
cijenaPoGostu.value=`${cijena}`;
ukupnaCijena.value=`${cijena}`;
}

let generisiPromjenuGradova = (boravakGradovi) => {
    let b=0;
    vrijemeGradova.innerHTML = '';
    for (const o of boravakGradovi) {
        fetch(`http://api.openweathermap.org/data/2.5/weather?q=${o.nazivGrada}&appid=917b026a997320574cd4315b9bf4c73a`)
            .then(
                (response) => {
                    response.json().then((body) => {
console.log(body);
                        // Funkciji proslijediti potrebne parametre kako bi se generisali gradovi iz preuzetih podataka
                        generisiGradove(o.nazivGrada, body.main.temp, body.wind.speed, b++);
                    })
                }
            )
    }

}
let generisiGradove = (naziv,temp,speed,id) => {
    vrijemeGradova.innerHTML += `<div class="city-card">
    <h2 class="city-name">${naziv}<h2>
    <div class="city-card-right">
      <div class="wind-vel">
        <span>${speed}</span>
        <div class="propeller">
        ${generatePropeler(id)}

        </div>
      </div>
      <div class="temp">
        <span>T${temp}</span>
        ${generateTermometer(id)};

      </div>
    </div>
  </div>`
}
let getTempColor = (temp) => {
    if (temp >= 40)
        return 'red';
    if (temp < 40 && temp >= 30) {
        return 'rgb(235, 100, 52)'
    }
    if (temp < 30 && temp >= 20)
        return 'rgb(235, 134, 52)'
    if (temp < 20 && temp >= 10)
        return 'rgb(235, 211, 52)'
    if (temp < 10 && temp >= 0)
        return 'rgb(52, 235, 116)'
    if (temp < 0)
        return 'rgb(52, 58, 235)'
}
let setRotaciju = (vel, id) => {
    document.getElementById('propeller-' + id).style.animationDuration = `${10 / vel}s`;
}
let setTemperaturu = (color, id) => {
    document.getElementById('path1933-9-9-' + id).style.fill = color;
}

let ErrorBackgroundColor = "#FE7D7D";
let OkBackgroundColor = "#DFF6D8";
let nizGosa=[];
let posalji = () => {
    //https://wrd-fit.info/ -> Ispit20240713 -> Dodaj
    let sviMojiLjudi=document.querySelectorAll(".gosti-names");
    nizGosa.forEach((element) => {
        nizGosa.push(element.value)
    });

    let jsObjekat = {
        putovanjeID: globalID,
        drzava: drzavaG,
        mobitel:phone.value,
        datumPolaska: datum,
        cijenaUkupno:ukupnaCijena.value,
        gostiPutovanja:nizGosa,
        brojIndeksa:brojIndeksa.value,
        email:email.value,
        datumVazenjaPasosa: datumVazenjaPasosa.value,
      };

    let jsonString = JSON.stringify(jsObjekat);

    console.log(jsObjekat);

    let url = "https://wrd-fit.info/Ispit20240713/Dodaj";

    //fetch tipa "POST" i saljemo "jsonString"
    fetch(url, {
        method: "POST",
        body: jsonString,
        headers: {
            "Content-Type": "application/json",
        }
    })
        .then(r => {
            if (r.status != 200) {
                alert("Greška")
                return;
            }

            r.json().then(t => {

                if (t.idRezervacije != null && Number(ukupnaCijena.value) > 0) {
                    dialogSuccess(`Idi na placanje rezervacije broj ${t.idRezervacije} - iznos ${ukupnaCijena.value} EUR`, () => {
                        window.location = `https://www.paypal.com/cgi-bin/webscr?business=adil.joldic@yahoo.com&cmd=_xclick&currency_code=EUR&amount=${ukupnaCijena.value}&item_name=Dummy invoice`
                    });
                }
            })

        })
}

let ukupno=()=>{
    if(cijenaPoGostu.value===''){
        return;
    }
    ukupnaCijena.value=brojGostiju.value*cijenaPoGostu.value;
}

let promjenaBrojaGostiju = () => {
    gosti.innerHTML=``;
for(let i=0; i<brojGostiju.value;i++){
    gosti.innerHTML+=`
    <div>
    <label class="bold">Gost broj ${i+1}</label>
    <input type="text" class="gosti-names" id="gost-broj-${i}" oninput="provjeriGosta(${i})" />
  </div>
    `;
}
ukupno();
}
promjenaBrojaGostiju();

let provjeriTelefon = () => {
    let r = /^\+[0-9]{3}-[0-9]{2}-[0-9]{3}-[0-9]{3}$/;
    if (!r.test(phone.value)) {
        phone.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        phone.style.backgroundColor = OkBackgroundColor;
    }
}
let provjeriGosta=(i)=>{
    let r = /^[A-Z][a-z]{1,}\s[A-Z][a-z]{1,}$/;
    let gostic=document.getElementById(`gost-broj-${i}`);
    if (!r.test(gostic.value)) {
        gostic.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        gostic.style.backgroundColor = OkBackgroundColor;
    }
}
let provjeriBrojIndeksa = () => {
    let r = /^IB[0-9]{6}$/;
    if (!r.test(brojIndeksa.value)) {
        brojIndeksa.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        brojIndeksa.style.backgroundColor = OkBackgroundColor;
    }
}
let provjeriEmail = () => {
    let r = /^[a-z]+\.[a-z]+@(fit.ba|edu.fit.ba)$/;
    if (!r.test(email.value)) {
        email.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        email.style.backgroundColor = OkBackgroundColor;
    }
}

let provjeriDatumPasos = () => {
    let r = /^(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.(19|20)\d{2}$/;
    if (!r.test(datumVazenjaPasosa.value)) {
        datumVazenjaPasosa.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        datumVazenjaPasosa.style.backgroundColor = OkBackgroundColor;
    }
}
k1_preuzmiDrzave();